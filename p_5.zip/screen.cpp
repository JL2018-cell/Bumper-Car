#include <clocale>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "car.h"
#include "screen.h"
#include <fstream>
#include <cmath>
using namespace std;

// input the x,y coordinates, no output 
// to place the cursor at column x and row y of the terminal 
void screen::gotoxy(int x, int y)
{
	printf("%c[%d;%df", 0x1B, y, x);
}


// input car p, output nothing 
// display the player's point P on the screen 
void screen::showcar_p(car p)
{
	gotoxy(p.getx(), p.gety());
	cout<<"P";
	fflush(stdout);
}


// input car t, output nothing 
// display the target point T on the screen 
void screen::showcar_t(car t){
	gotoxy(t.getx(), t.gety());
	cout<<"T";
	fflush(stdout);
}


// no input, no output 
// to clear the screen after each time of game 
void screen::clrscr()
{
	printf("\033[8;40;120t");
	fflush(stdout);
	system("clear");
}


// no input, no output 
// to show the game's guideline on the terminal 
void screen::showrule()
{
	this->gotoxy(83, 3);
	cout<<"Game Rules:";
	this->gotoxy(83, 4);
	cout<<"1. Bump the target out of the arena by setting the direction and primary speed";
	this->gotoxy(83, 5);
	cout<<"2. Two points in the arena, \"P\" is controlled by you, \"T\" is the target";
	this->gotoxy(83, 6);
	cout<<"3. Input direction by \"+number\" or \"-number\", the number is int in [0,180)";
	this->gotoxy(83, 7);
	cout<<"4. \"+\" means rotate counterclockwise, \"-\" means rotate clockwise";
	this->gotoxy(83, 8);
	cout<<"5. Set the primary speed by \"number\", the number is int in [1,15]";
	this->gotoxy(83, 9);
	cout<<"6. Only the case T is bumped out and P remains will be regarded as WIN";
	this->gotoxy(83, 10);
	cout<<"7. Five rounds of game in total, WIN for 3 rounds or more is regarded success";

}


// input p and t, no ouput 
// plot the motion curve of p before the moment of collision
void screen::plot_p_befcol(car & p, car & t)
{
	int px,tx,py,ty; /*x,y coordinate of p and t*/
	px=p.getx();
	tx=t.getx();
	py=p.gety();
	ty=t.gety();
	if(tx==px){
		if(py>ty){
			for(int y=py;y>ty;y--){				
				gotoxy(px,y);
				wcout<< L'\u2592';							
			}
			gotoxy(tx,ty);
			cout<<"P";
		}
		if(py<ty){
			for(int y=py;y<ty;y++){				
				gotoxy(px,y);
				wcout<< L'\u2592';				
			}
			gotoxy(tx,ty);
			cout<<"P";
		}

	}
	
	if(py==ty){
		if(tx>px){
			for(int x=px;x<tx;x++){				
				gotoxy(x,py);
				wcout<< L'\u2592';
				
			}
			gotoxy(tx,ty);
			cout<<"P";
		}
		if(tx<px){
			for(int x=px;x>tx;x--){				
				gotoxy(x,py);
				wcout<< L'\u2592';				
			}
			gotoxy(tx,ty);
			cout<<"P";

		}

	}

	if(px!=tx && py!=ty){
		double k=p.getk(t);
		double b=p.getb();
		if(tx>px){
			gotoxy(px,py);
			wcout<< L'\u2592';			
			for(int x=px+1;x<tx;x++){
				int y = (int) k*x+b;
				gotoxy(x,y);
				wcout<< L'\u2592';			
				
			}			
			gotoxy(tx,ty);
			cout<<"P";					
		}

		if(tx<px){
			gotoxy(px,py);
			wcout<< L'\u2592';			
			for(int x=px-1;x<tx;x++){
				int y = (int) k*x+b;
				gotoxy(x,y);
				wcout<< L'\u2592';				
				
			}			
			gotoxy(tx,ty);
			cout<<"P";					
		}

    }
}


// input p and t, no ouput 
// plot the motion curve of t after the moment of collision
void screen::plot_t_aftcol(car & p, car & t){
	double k=p.getk(t);
	double b=p.getb();
	int px=p.getx(),py=p.gety(),tx=t.getx(),ty=t.gety();	
	int x=tx,y=ty;
	if(p.check_t_out()){
		if(px==tx){
		    if(py>ty){
			    for(int y=ty;y>0;y--){				    
				    gotoxy(tx,y);
				    wcout<< L'\u2592';
				    			
			    }
				gotoxy(tx,0);
				cout<<"T";
		    }

		    if(py<ty){
			    for(int y=py;y<40;y++){				    
				    gotoxy(tx,y);
				    wcout<< L'\u2592';				    				
			    }
				gotoxy(tx,40);
				cout<<"T";
		    }

	    }

	    if(py==ty){
		    if(tx>px){
			    for(int x=tx;x<80;x++){				    
				    gotoxy(x,ty);
				    wcout<< L'\u2592';				    			
			    }
				gotoxy(80,ty);
				cout<<"T";
		    }

		    if(tx<px){
			    for(int x=tx;x>0;x--){				    
				    gotoxy(x,ty);
				    wcout<< L'\u2592';				    
			    }
				gotoxy(0,ty);
				cout<<"T";
		    }
		
	    }

	    if(px!=tx && py!=ty){
            double k=p.getk(t);
		    double b=p.getb();
		    while(x>0 && x<80 && y>=0 && y<=40){			
			    if(tx>px){				
				    gotoxy(x,y);
				    wcout<< L'\u2592';				    
				    int x1=x+1;
				    int y1= (int) k*x1+b;
				    gotoxy(x1,y1);
				    wcout<< L'\u2592';				    
				    y=y1;
				    x++;			
			    }

                if(tx<px){				
				    gotoxy(x,y);
				    wcout<< L'\u2592';				    
				    int x1=x-1;
				    int y1= (int) k*x1+b;
				    gotoxy(x1,y1);
				    wcout<< L'\u2592';				    
				    y=y1;
				    x--;			
		        }
	        }		
	    }
    }
}	

	



// no input, no output 
// print out the rectangle arena on the screen
void screen::arena()
{
	gotoxy(0, 0);
	for (int i = 0; i < col; i++) {
		cout << "-";
	}
	for (int j = 0; j < row; j++) {
		gotoxy(0, j);
		cout << "|";
		gotoxy(col, j);
		cout << "|";
	}
	gotoxy(0, row);
	for (int i = 0; i < col; i++) {
		cout << "-";
	}
	fflush(stdout);

}
